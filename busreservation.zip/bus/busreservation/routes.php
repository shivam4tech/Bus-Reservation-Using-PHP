<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to SAS Bus service</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header">
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
            <li class="current"><a href="routes.php">Routes</a></li>
            <li><a href="contact.php">Contact Us</a></li>
    	</ul>
	</div>
    
    <div id="content">
    <div class="row">
  <div class="col-md-12">
  <marquee behavoiur="alternate"  direction="right" scrollamount="10" 
onmouseover="stop()"
onmouseout="start()">
<font face="arial" color="aqua" size="3">
<h3><strong>WELCOME TO SAS TRANSPORT</strong></h3><br />
</font> 

</marquee>
<br />
  
  </div>
</div>
    	<div id="gallerycontainer">
			<div class="portfolio-area" style="margin:0 auto; padding:140px 20px 20px 20px; width:820px;">	
					<table cellspacing="0" cellpadding="0" border="0" style="width: 449px;"><colgroup><col width="136"> <col width="179"> <col width="134"> </colgroup>

<tbody>
<tr>
<td width="136" height="24" class="xl65"><span style="color: #000000;">SOURCE:</span></td>
<td width="179" class="xl66"><span style="color: #000000;">KANPUR</span></td>
<td width="134" class="xl67">&nbsp;</td>
</tr>
<tr>
<td width="136" height="22" class="xl66"><span style="color: #000000;">DESTINATION</span></td>
<td width="179" class="xl67"><span style="color: #000000;">DEPARTURE</span></td>
<td width="134" class="xl67"><span style="color: #000000;">TYPE</span></td>
<td width="134" class="xl67"><span style="color: #000000;">PRICE(PER SEAT)</span></td>
</tr>
<tr>
<td width="136" height="22" class="xl69"><span style="color: #000000;">LUCKNOW</span></td>
<td width="179" class="xl70"><span style="color: #000000;">09:00AM</span></td>
<td width="134" class="xl71"><span style="color: #000000;">AIR CON</span></td>
<td width="134" class="xl67"><span style="color: #000000;">Rs.200</span></td>
</tr>
<tr>
<td width="136" height="22" class="xl69"><span style="color: #000000;">LUCKNOW</span></td>
<td width="179" class="xl70"><span style="color: #000000;">10:00AM</span></td>
<td width="134" class="xl71"><span style="color: #000000;">DELUXE</span></td>
<td width="134" class="xl67"><span style="color: #000000;">Rs.300</span></td>
</tr>
<tr>
<td width="136" height="22" class="xl69"><span style="color: #000000;">LUCKNOW</span></td>
<td width="179" class="xl70"><span style="color: #000000;">18:00PM</span></td>
<td width="134" class="xl71"><span style="color: #000000;">AIR CON</span></td>
<td width="134" class="xl67"><span style="color: #000000;">Rs.200</span></td>
</tr>
<tr>
<td width="136" height="22" class="xl69"><span style="color: #000000;">LUCKNOW</span></td>
<td width="179" class="xl68"><span style="color: #000000;">20:00PM</span></td>
<td width="134" class="xl71"><span style="color: #000000;">DELUXE</span></td>
<td width="134" class="xl67"><span style="color: #000000;">Rs.300</span></td>
</tr>
<tr>
<td width="136" height="22" class="xl69">&nbsp;</td>
<td width="179" class="xl68">&nbsp;</td>
<td width="134" class="xl68">&nbsp;</td>
</tr>
<tr>
<td width="136" height="22" class="xl69">&nbsp;</td>
<td width="179" class="xl68">&nbsp;</td>
<td width="134" class="xl68">&nbsp;</td>
</tr>
<tr>
<td width="136" height="22" class="xl65"><span style="color: #000000;">SOURCE:</span></td>
<td width="179" class="xl66"><span style="color: #000000;">KANPUR</span></td>
<td width="134" class="xl67">&nbsp;</td>
</tr>
<tr>
<td width="136" height="22" class="xl66"><span style="color: #000000;">DESTINATION</span></td>
<td width="179" class="xl67"><span style="color: #000000;">DEPARTURE</span></td>
<td width="134" class="xl67"><span style="color: #000000;">TYPE</span></td>
<td width="134" class="xl67"><span style="color: #000000;">PRICE(PER SEAT)</span></td>
</tr>
<tr>
<td width="136" height="22" class="xl69"><span style="color: #000000;">DELHI</span></td>
<td width="179" class="xl68"><span style="color: #000000;">09:00AM</span></td>
<td width="134" class="xl71"><span style="color: #000000;">AIR CON</span></td>
<td width="134" class="xl67"><span style="color: #000000;">Rs.700</span></td>
</tr>
<tr>
<td width="136" height="22" class="xl69"><span style="color: #000000;">DELHI</span></td>
<td width="179" class="xl68"><span style="color: #000000;">10:00AM</span></td>
<td width="134" class="xl71"><span style="color: #000000;">DELUXE</span></td>
<td width="134" class="xl67"><span style="color: #000000;">Rs.900</span></td>
</tr>
<tr>
<td width="136" height="22" class="xl69"><span style="color: #000000;">DELHI</span></td>
<td width="179" class="xl68"><span style="color: #000000;">18:00PM</span></td>
<td width="134" class="xl71"><span style="color: #000000;">AIR CON</span></td>
<td width="134" class="xl67"><span style="color: #000000;">Rs.700</span></td>
</tr>
<tr>
<td width="136" height="22" class="xl69"><span style="color: #000000;">DELHI</span></td>
<td width="179" class="xl68"><span style="color: #000000;">20:00PM</span></td>
<td width="134" class="xl71"><span style="color: #000000;">DELUXE</span></td>
<td width="134" class="xl67"><span style="color: #000000;">Rs.900</span></td>
</tr>
<tr>
<td width="136" height="22" class="xl69">&nbsp;</td>
<td width="179" class="xl68">&nbsp;</td>
<td width="134" class="xl71">&nbsp;</td>
</tr>
<tr>
<td height="22">&nbsp;</td>
<td width="179" class="xl68">&nbsp;</td>
<td width="134" class="xl71">&nbsp;</td>
</tr>
<tr>
<td width="136" height="22" class="xl65"><span style="color: #000000;">SOURCE:</span></td>
<td width="179" class="xl66"><span style="color: #000000;">KANPUR</span></td>
<td width="134" class="xl67">&nbsp;</td>
</tr>
<tr>
<td width="136" height="22" class="xl66"><span style="color: #000000;">DESTINATION</span></td>
<td width="179" class="xl67"><span style="color: #000000;">DEPARTURE</span></td>
<td width="134" class="xl67"><span style="color: #000000;">TYPE</span></td>
<td width="134" class="xl67"><span style="color: #000000;">PRICE(PER SEAT)</span></td>
</tr>
<tr>
<td width="136" height="22" class="xl69"><span style="color: #000000;">ALLAHABAD</span></td>
<td width="179" class="xl68"><span style="color: #000000;">09:00AM</span></td>
<td width="134" class="xl71"><span style="color: #000000;">AIR CON</span></td>
<td width="134" class="xl67"><span style="color: #000000;">Rs.400</span></td>
</tr>
<tr>
<td width="136" height="22" class="xl69"><span style="color: #000000;">ALLAHABAD</span></td>
<td width="179" class="xl68"><span style="color: #000000;">10:00AM</span></td>
<td width="134" class="xl71"><span style="color: #000000;">DELUXE</span></td>
<td width="134" class="xl67"><span style="color: #000000;">Rs.600</span></td>
</tr>
<tr>
<td height="22"><span style="color: #000000;">ALLAHABAD</span></td>
<td width="179" class="xl68"><span style="color: #000000;">18:00PM</span></td>
<td width="134" class="xl71"><span style="color: #000000;">AIR CON</span></td>
<td width="134" class="xl67"><span style="color: #000000;">Rs.400</span></td>
</tr>
<tr>
<td height="22"><span style="color: #000000;">ALLAHABAD</span></td>
<td width="179" class="xl68"><span style="color: #000000;">20:00PM</span></td>
<td width="134" class="xl71"><span style="color: #000000;">DELUXE</span></td>
<td width="134" class="xl67"><span style="color: #000000;">Rs.600</span></td>
</tr>
<tr>
<td height="20">&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
</tbody>
</table>
				<div class="column-clear"></div>
            </div>
			<div class="clearfix"></div>
        </div>
    </div>
</div>
</body>
</html>
