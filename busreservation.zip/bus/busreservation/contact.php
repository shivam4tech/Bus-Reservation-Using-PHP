<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to SAS bus service</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
</head>

<body>
<div id="wrapper">
	<div id="header">
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
            <li><a href="routes.php">Routes</a></li>
            <li class="current"><a href="contact.php">Contact Us</a></li>
    	</ul>
	</div>
  
    <div id="content">
      <div class="row">
  <div class="col-md-12">
  <marquee behavoiur="alternate"  direction="right" scrollamount="10" 
onmouseover="stop()"
onmouseout="start()">
<font face="arial" color="khaki" size="3">
<h3><strong>WELCOME TO SAS TRANSPORT</strong></h3><br />
</font> 

</marquee>
<br />
  
  </div>
</div>
    	<div id="gallerycontainer">
			<div class="portfolio-area" style="margin:0 auto; padding:140px 20px 20px 20px; width:820px;">	
				<div id="contactleft">
					<B><strong>SAS BUS</strong></B><br>
(SAS TRANSPORT, INCORPORATED)<br>
Transport Nagar,Kanpur<br>
Phone:  +91 9793656165<br><br>


Contact Numbers:<br>
SAS Bus Company Lucknow<br>
  +91-8090740439<br>
				</div><br>
				
               	<div class="column-clear"></div>
            </div>
			<div class="clearfix"></div>
        </div>
    </div>


</div>
</body>
</html>
